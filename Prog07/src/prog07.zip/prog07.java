import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JFileChooser;
import java.io.PrintWriter;
public class prog07 {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub	
		try {
			int [] grade = array();
			BubbleSort(grade);
			result(grade);
		}
		
		catch (FileNotFoundException e) {
			System.out.println("File Not Found!");
		}
		
		catch (SecurityException e) {
			System.out.println("x");
		}
			
	}//main
		
		public static int[] array() throws FileNotFoundException {
			JFileChooser chooser = new JFileChooser();
			Scanner in = null;
			if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			
				File selectedFile = chooser.getSelectedFile();
				in = new Scanner(selectedFile);
			
			}
			int [] array = new int[in.nextInt()];
			
			while (in.hasNextInt()) {
				for (int i = 0; i < array.length; i++) {
					array[i] = in.nextInt();
				}
			}
			in.close();
			
			return array;
		} //int array method
		
		public static int[] BubbleSort (int[] array) {
			boolean sorted = false;
			int i = 1;
			while (!sorted) {
				if (i == array.length) {
					sorted = true;
				}//if
				else {
					sorted = true;
					for(int j = 0; j < array.length-i; j++){
						if(array[j] < array[j+1]) {
							swap(array, j, j+1);
							sorted = false;
						}//if
					}//for
				}//else
				i++;
			}//while
			return array;
		}//bubbleSort
	
		public static int [] swap( int[] gradess, int i, int j) {
			
			int temp = gradess[i];
			gradess[i] = gradess[j];
			gradess[j] = temp;
			
			return gradess;
		}
		
		public static void result (int[] grade) throws FileNotFoundException {
			
			JFileChooser chooser = new JFileChooser();
			
			if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
				File outFile = chooser.getSelectedFile();
				PrintWriter out = new PrintWriter(outFile);
				
				for (int i = 0; i < grade.length; i++) {
					out.println(grade[i]);
				}
				out.close();
			}
		}
		
	}//class

